#!/bin/bash

# 系统环境检查
# author baochunliang 2018-03-19

OS_VERSION=$(get_os_version)
OS_BIT=$(get_os_bit)

if [ "$OS_BIT" == "64" ]; then
	echo "操作系统版本为64bit..."
else
    echo "操作系统版本不是64bit，不满足依赖，退出安装..."
    exit 1
fi

case "$(version_compare $OS_VERSION 7)" in
	"=")
		echo
		echo "操作系统版本为CentOS(Red Hat) $OS_VERSION"
    	;;
	">")
		echo
		echo "操作系统版本为CentOS(Red Hat) $OS_VERSION"
		;;
	"<")
		echo
		echo "当前操作系统版本$OS_VERSION，不满足依赖（最低支持CentOS 7），退出安装..."
		exit 1
		;;
esac

# JDK环境检查
if [ "$JAVA_HOME" == "" ];then
	echo "JAVA_HOME不存在，请安装jdk并配置JAVA_HOME之后再进行安装..."
	exit 1;
fi
STANDARDVERSION=180000
JAVA_VERSION=`java -version 2>&1 | awk '/java version/ {print $3}' | awk -F '\"' '{print $2}'`
JAVA_VERSION_FRONT=`echo $JAVA_VERSION | awk -F '_' '{print $1}'`
JAVA_VERSION_FRONT_1=`echo $JAVA_VERSION_FRONT | awk -F '.' '{print $1}'`
JAVA_VERSION_FRONT_2=`echo $JAVA_VERSION_FRONT | awk -F '.' '{print $2}'`
JAVA_VERSION_FRONT_3=`echo $JAVA_VERSION_FRONT | awk -F '.' '{print $3}'`
JAVA_VERSION_BACK=`echo $JAVA_VERSION | awk -F '_' '{print $2}'`
CUREENTVERSION=$(($JAVA_VERSION_FRONT_1*100000+$JAVA_VERSION_FRONT_2*10000+$JAVA_VERSION_FRONT_3*1000+$JAVA_VERSION_BACK))
if (( $CUREENTVERSION >= $STANDARDVERSION ));then
	success "已安装JDK $JAVA_VERSION"
else
	echo
	failure "当前安装JDK $JAVA_VERSION，此版本有可能导致程序不能正常运行（最低要求jdk1.8）"
	exit 1
fi
