#!/bin/bash

# author baochunliang 2018-04-08

SKIP_CONFIRM=$1

if [ "$SKIP_CONFIRM" != "skip" ]; then
	echo
	echo -n "是否执行卸载脚本（y/n，默认n）："
	read CONFIRM
	if [ "$CONFIRM" != "y" -a "$CONFIRM" != "n" ]; then
		CONFIRM="n"
	fi
	
	if [ "$CONFIRM" == "n" ]; then
		echo "取消执行卸载脚本"
	    exit 1
	fi
fi

echo
echo "开始执行卸载脚本..."

MODULE="thirdsync"
SERVICE_NAME="appnest_${MODULE}"
SCRIPT_PATH="$( cd "$(dirname "$0")" ; pwd -P )"
LATEST_PATH="$( cd /home/appnest/${MODULE}/${MODULE} ; pwd -P )"

if [ "${SCRIPT_PATH}" == "${LATEST_PATH}" ]
then
	echo
	echo "停止${SERVICE_NAME}服务..."
	systemctl stop ${SERVICE_NAME}
fi

echo
echo "清除${SERVICE_NAME}系统文件"
rm -rf ${SCRIPT_PATH}
echo "清除完成"

if [ "${SCRIPT_PATH}" == "${LATEST_PATH}" ]
then
	echo
	echo "卸载${SERVICE_NAME}服务..."
	rm -f /etc/systemd/system/${SERVICE_NAME}.service
	rm -f /etc/systemd/system/multi-user.target.wants/${SERVICE_NAME}.service
	systemctl daemon-reload
	rm -f /home/appnest/${MODULE}/${MODULE}
fi

echo
echo "卸载完成"

exit 0