#!/bin/bash

# 工具方法
# author baochunliang 2018-03-19

TEXTDOMAIN=initscripts

COLUMN_SIZE=60

success()
{
    echo -en "$1\\033[${COLUMN_SIZE}G["
    echo -n $"  OK  "
    echo -en "]\n"
    return 0
}

failure()
{
    echo -en "$1\\033[${COLUMN_SIZE}G["
    echo -n $"FAILED"
    echo -en "]\n"
    return 1
}

check_root_priv()
{
    if [ "$UID" != 0 ]; then
        echo
        failure "当前用户不具备管理员权限，请使用管理员账户安装"
        exit 1
    fi
}

get_os_bit()
{
    echo $(getconf LONG_BIT|head -n 1)
}

get_os_version()
{
    local version=$(cat /etc/redhat-release |grep -Po "\d+\.\d+")
    echo ${version%%.*}
}

# 返回值(= > <)
version_compare()
{
    if [[ $1 == $2 ]]
    then
        echo "=" &&return
    fi
    local IFS=.
    local i ver1=($1) ver2=($2)
    # fill empty fields in ver1 with zeros
    for ((i=${#ver1[@]}; i<${#ver2[@]}; i++))
    do
        ver1[i]=0
    done
    for ((i=0; i<${#ver1[@]}; i++))
    do
        if [[ -z ${ver2[i]} ]]
        then
            # fill empty fields in ver2 with zeros
            ver2[i]=0
        fi
        if ((10#${ver1[i]} > 10#${ver2[i]}))
        then
            echo ">" &&return
        fi
        if ((10#${ver1[i]} < 10#${ver2[i]}))
        then
            echo "<" &&return
        fi
    done
    echo "=" &&return
}

#文件所有者
get_own_user()
{
    echo $(stat -c "%U" "$1")
}

#截取最后一个逗号
cut_last_comma()
{	
	STR=$1
    FINAL_CHAR=`echo ${STR: -1}`
	if [ $FINAL_CHAR == ',' ]; then
		LENGTH=`echo ${#STR}`
    	let LENGTH--
    	STR=`echo ${STR:0:$LENGTH}`
    fi
    echo $STR
}