#!/bin/bash

#thirdsync自动安装脚本

source ~/.bash_profile

SUB_SYS_NAME=thirdsync
USER_NAME=appnest
GROUP_NAME=nationsky

APPNEST_HOME=/home/$USER_NAME
SUB_SYS_HOME=$APPNEST_HOME/$SUB_SYS_NAME

ROOT_PATH=$(cd -P $(dirname $0) &&pwd)
SHELL_PATH=$ROOT_PATH/shell
BASE_NAME=$(basename $ROOT_PATH)

cd $ROOT_PATH
. $SHELL_PATH/util.sh

check_root_priv

NEED_UPDATE=0
last_version=""

#版本比较
base_version=${BASE_NAME#appnest_thirdsync-}
for installed_version in $(ls $SUB_SYS_HOME 2>&1|grep -Po '\d\.\d\.\d'); do
	case "$(version_compare $base_version $installed_version)" in
		"=")
			echo
            failure "版本$base_version已安装，请先卸载当前版本再执行安装"
            exit
            ;;
        ">")
            NEED_UPDATE=1
            last_version=$installed_version
            ;;
        "<")
            echo
            failure "已安装更高的版本$installed_version"
            exit
            ;;
    esac
done

SUB_SYS_VER_HOME=$SUB_SYS_HOME/$base_version

echo
if [ "$NEED_UPDATE" == "0" ];then
    echo "执行appnest_thirdsync自动安装脚本，安装目录【$SUB_SYS_VER_HOME】"
else
    echo "执行appnest_thirdsync自动升级脚本，安装目录【$SUB_SYS_VER_HOME】"
fi

echo &&echo "系统环境检查..."
. $SHELL_PATH/check_system.sh

echo
echo "创建执行用户组..."
GROUP_INFO=`cat /etc/group |grep -i "^$GROUP_NAME"`
if [ ! -z "$GROUP_INFO" ]; then
    success "用户组已存在"
else
    groupadd $GROUP_NAME
fi

echo
echo "创建执行用户..."
USER_INFO=`cat /etc/passwd |grep -i "^$USER_NAME:"`
if [ ! -z "$USER_INFO" ]; then
    success "用户已存在"
else
    useradd -m -g $GROUP_NAME -p $(openssl passwd -1 $USER_NAME) $USER_NAME
    usermod -G root $USER_NAME
    success "用户创建成功"
fi

#创建目录并赋权
function create_path()
{
	if [ ! -d "$1" ]; then
	    mkdir -p "$1"
		chown $USER_NAME "$1" -R
		chgrp $GROUP_NAME "$1" -R
		chmod 775 "$1" -R
	fi
}

echo
echo "释放文件，请稍候..."

cd $ROOT_PATH
mkdir -p $SUB_SYS_VER_HOME/logs
/bin/cp -rpf $ROOT_PATH/* $SUB_SYS_VER_HOME
/bin/cp -pf $SHELL_PATH/uninstall.sh $SUB_SYS_VER_HOME

#升级时需要先删除原先的软连接
if [ "$NEED_UPDATE" == "1" ];then
	rm -f $SUB_SYS_HOME/thirdsync
fi

ln -s $SUB_SYS_VER_HOME/ $SUB_SYS_HOME/thirdsync

cd $APPNEST_HOME/

chown -h appnest thirdsync
chgrp -h nationsky thirdsync
chmod 755 thirdsync

chown appnest $SUB_SYS_HOME -R
chgrp nationsky $SUB_SYS_HOME -R
chmod 755 $SUB_SYS_HOME -R

success "释放完成"

echo
echo "修改配置文件..."
cd $SUB_SYS_VER_HOME/configs/

echo
echo "清理安装目录..."
rm -rf $SUB_SYS_VER_HOME/shell
rm -rf $SUB_SYS_VER_HOME/install.sh
success "清理完成"

echo
echo "配置appnest_thirdsync服务..."
TEMP_HOME=`echo ${JAVA_HOME} | sed 's:\/:\\\/:g'`
sed -i 's/TEMP_HOME/'"${TEMP_HOME}"'/g' $SUB_SYS_VER_HOME/bin/appnest_thirdsync.service
#升级时需要先删除原先的服务
if [ "$NEED_UPDATE" == "1" ];then
	rm -rf /etc/systemd/system/appnest_thirdsync.service
	rm -rf /etc/systemd/system/multi-user.target.wants/appnest_thirdsync.service
fi
\cp -f $SUB_SYS_VER_HOME/bin/appnest_thirdsync.service /etc/systemd/system/appnest_thirdsync.service
ln -s /etc/systemd/system/appnest_thirdsync.service /etc/systemd/system/multi-user.target.wants/appnest_thirdsync.service
systemctl daemon-reload
success "服务配置完成"
echo "服务usage：systemctl start/stop/restart/status appnest_thirdsync"

echo
echo "启动appnest_thirdsync服务"

systemctl restart appnest_thirdsync

echo "安装脚本执行结束，日志目录：/home/appnest/thirdsync/thirdsync/logs/"
echo

#echo "请检查配置文件后执行systemctl start appnest_thirdsync启动服务"
#success "安装脚本执行结束"

exit 0
